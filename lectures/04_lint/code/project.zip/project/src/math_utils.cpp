// math_utils.cpp
#include <math_utils.hpp>

int add(int a, int b) { return a + b; }

int sub(int a, int b) { return a - b; }