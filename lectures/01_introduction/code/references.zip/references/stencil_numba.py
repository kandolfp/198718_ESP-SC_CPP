from numba import jit
import numpy as np

@jit(nopython=True)
def compute(inn, out, N, alpha):
    for i in np.arange(1, N - 1):
        for j in np.arange(1, N - 1):
            out[j + i * N] = inn[j + i * N] \
                        + alpha * (inn[j - 1 + i * N] - 2.0 * inn[j + i * N] + inn[j + 1 + i * N])
            
if __name__ == "__main__":
    N = 2_000  # Grid size
    alpha = 0.5  # Example value for alpha

    # Initialize input and output arrays
    inn = np.ones(N * N)  # Input array filled with 1.0
    out = np.zeros(N * N)  # Output array initialized to 0.0

    # Call the compute function
    compute(inn, out, N, alpha)
    compute(inn, out, N, alpha)
    print(f"Computation complete. Example output value: {out[N // 2 + (N // 2) * N]}")