#include <iostream>
#include <map>

int main() {
  std::map<std::string, int> ages = {
      {"Alice", 25}, {"Bob", 30}, {"Charlie", 35}};

  // Range-based for loop with a map
  for (const auto &pair : ages) {
    std::cout << pair.first << ": " << pair.second << "\n";
  }

  return 0;
}