import numpy as np

def compute(inn, out, N, alpha):
    # Compute indices for the 1D array
    indices = np.arange(N * N).reshape(N, N)  # Reshape to 2D for easier indexing
    inner_indices = indices[1:-1, 1:-1].ravel()  # Flatten the inner grid indices
    left_indices = inner_indices - 1
    right_indices = inner_indices + 1

    # Perform the computation
    out[inner_indices] = inn[inner_indices] + alpha * (
        inn[left_indices] - 2.0 * inn[inner_indices] + inn[right_indices]
    )
            
if __name__ == "__main__":
    N = 2_000  # Grid size
    alpha = 0.5  # Example value for alpha

    # Initialize input and output arrays
    inn = np.ones(N * N)  # Input array filled with 1.0
    out = np.zeros(N * N)  # Output array initialized to 0.0

    # Call the compute function
    compute(inn, out, N, alpha)
    compute(inn, out, N, alpha)
    print(f"Computation complete. Example output value: {out[N // 2 + (N // 2) * N]}")