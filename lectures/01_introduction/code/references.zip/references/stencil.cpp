#include <iostream>
#include <vector>

void compute(const std::vector<double> &in, std::vector<double> &out, int N,
             double alpha) {
  for (int i = 1; i < N - 1; i++) {
    for (int j = 1; j < N - 1; j++) {
      out[j + i * N] =
          in[j + i * N] +
          alpha * (in[j - 1 + i * N] - 2.0 * in[j + i * N] + in[j + 1 + i * N]);
    }
  }
}

int main() {
  const int N = 2000; // Grid size
  double alpha = 0.5; // Example value for alpha

  // Initialize input and output arrays
  std::vector<double> in(N * N, 1.0);  // Input array filled with 1.0
  std::vector<double> out(N * N, 0.0); // Output array initialized to 0.0

  // Perform the computation
  compute(in, out, N, alpha);
  compute(in, out, N, alpha);

  // Optional: Print some results for verification
  std::cout << "Computation complete. Example output value: "
            << out[N / 2 + (N / 2) * N] << std::endl;

  return 0;
}